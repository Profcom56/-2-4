import { cn } from "@/utils/cn";

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <a href="#hero" className={cn("group inline-flex items-center gap-3", className)} aria-label="Profcom — на главную">
      <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl bg-gradient-to-br from-ember-400 to-ember-600 shadow-glow">
        {/* Силуэт бани-квадро */}
        <svg viewBox="0 0 24 24" className="h-6 w-6 text-coal-950" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 20V11a8 8 0 0 1 16 0v9" />
          <path d="M4 20h16" />
          <path d="M10 20v-5h4v5" />
          <path d="M15 5V2" />
        </svg>
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-lg font-bold tracking-tight text-cream-50">
            Prof<span className="text-ember-400">com</span>
          </span>
          <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.28em] text-cream-500">бани-бочки</span>
        </span>
      )}
    </a>
  );
}
