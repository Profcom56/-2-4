import { useState } from "react";
import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { SPECS, MODEL } from "@/data/content";
import { IMAGES } from "@/data/images";
import { cn } from "@/utils/cn";

const HOTSPOTS = [
  { x: 19, y: 58, title: "Дровяная печь", text: "С каменкой — быстрый мягкий пар" },
  { x: 36, y: 66, title: "Бак для воды", text: "Горячая вода без электричества" },
  { x: 24, y: 19, title: "Термогигрометр", text: "Контроль температуры и влажности" },
  { x: 68, y: 26, title: "Окно", text: "Дневной свет и проветривание" },
  { x: 74, y: 52, title: "Полки в два яруса", text: "Сидеть или лежать — как удобно" },
];

export function Specs({ index, total }: { index: number; total: number }) {
  const [active, setActive] = useState<number | null>(null);

  return (
    <Section id="specs" index={index} total={total} className="bg-coal-900">
      <div className="pointer-events-none absolute -right-40 bottom-0 h-[480px] w-[480px] rounded-full bg-ember-600/10 blur-[140px]" />
      <Container>
        <div className="grid items-center gap-12 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-5">
            <Reveal>
              <Eyebrow>Характеристики</Eyebrow>
              <Title>
                Продумано
                <br />
                <span className="text-cream-400">до мелочей</span>
              </Title>
              <Lead>
                «{MODEL}» — это прямые стены и скруглённая крыша из кедра: внутри просторнее, чем в классической бочке,
                а снаружи — аккуратный современный силуэт.
              </Lead>
            </Reveal>

            <Reveal delay={150}>
              <div className="relative mt-8 overflow-hidden rounded-3xl border border-cream-50/10 shadow-card">
                <div className="relative aspect-[3/2]">
                  <img src={IMAGES.steam} alt="Парная бани-бочки Квадро" className="h-full w-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-950/50 to-transparent" />
                  {HOTSPOTS.map((h, i) => (
                    <div
                      key={h.title}
                      className="absolute"
                      style={{ left: `${h.x}%`, top: `${h.y}%` }}
                      onMouseEnter={() => setActive(i)}
                      onMouseLeave={() => setActive(null)}
                    >
                      <button
                        onClick={() => setActive(active === i ? null : i)}
                        className="relative grid h-6 w-6 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-ember-400 text-coal-950 shadow-glow"
                        aria-label={h.title}
                      >
                        <span className="absolute inset-0 rounded-full bg-ember-400 animate-pulse-ring" />
                        <span className="relative h-2 w-2 rounded-full bg-coal-950" />
                      </button>
                      <div
                        className={cn(
                          "pointer-events-none absolute left-1/2 top-3 z-10 w-44 -translate-x-1/2 rounded-xl border border-cream-50/10 bg-coal-950/90 p-3 text-left shadow-card backdrop-blur transition-all duration-300",
                          active === i ? "translate-y-0 opacity-100" : "translate-y-1 opacity-0",
                          h.x > 60 && "left-auto right-0 translate-x-3",
                        )}
                      >
                        <div className="text-sm font-semibold text-cream-50">{h.title}</div>
                        <div className="mt-0.5 text-xs leading-snug text-cream-400">{h.text}</div>
                      </div>
                    </div>
                  ))}
                  <div className="absolute bottom-3 left-3 rounded-full bg-coal-950/60 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-cream-300 backdrop-blur">
                    наведите на точки
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
              {SPECS.map((s, i) => (
                <Reveal key={s.label} delay={i * 60}>
                  <div className="group h-full rounded-2xl border border-cream-50/10 bg-coal-800/60 p-5 transition-colors duration-300 hover:border-ember-400/40 hover:bg-coal-800">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cream-500">{s.label}</div>
                    <div className="mt-3 whitespace-nowrap font-display text-xl font-semibold leading-none tracking-tight text-cream-50 transition-colors group-hover:text-ember-300 sm:text-2xl">
                      {s.value}
                    </div>
                    <div className="mt-2 text-xs text-cream-400">{s.note}</div>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={400}>
              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                {[
                  { k: "Парная", v: "2 × 2 м", d: "печь, полки в два яруса" },
                  { k: "Предбанник", v: "2 × 2 м", d: "лавка, окно, вешалки" },
                  { k: "Высота", v: "≈ 2,2 м", d: "комфортно стоять в полный рост" },
                ].map((b) => (
                  <div key={b.k} className="flex items-center gap-4 rounded-2xl border border-ember-400/20 bg-ember-400/5 p-4">
                    <div className="shrink-0 whitespace-nowrap font-display text-xl font-semibold text-ember-300">{b.v}</div>
                    <div>
                      <div className="text-sm font-semibold text-cream-50">{b.k}</div>
                      <div className="text-xs text-cream-400">{b.d}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </Section>
  );
}
