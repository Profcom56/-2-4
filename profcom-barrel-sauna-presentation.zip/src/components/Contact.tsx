import { useState, type FormEvent, type ReactNode } from "react";
import { Container, Eyebrow, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { Button, ButtonLink } from "@/components/ui/Button";
import { CheckIcon, CopyIcon, MaxIcon, PhoneIcon, TelegramIcon, ClockIcon, ShieldIcon, TruckIcon } from "@/components/ui/Icons";
import {
  COMPANY,
  MANAGER,
  MANAGER_DATIVE,
  MAX_NAME,
  MAX_PROFILE_URL,
  MODEL,
  PHONE_DISPLAY,
  PHONE_TEL,
  PRICE_DISPLAY,
  SIZE,
  TELEGRAM_URL,
  maxUrl,
} from "@/data/content";
import { IMAGES } from "@/data/images";

export function Contact({ index, total }: { index: number; total: number }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [comment, setComment] = useState("");
  const [sent, setSent] = useState(false);
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);

  const copyMessage = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      /* буфер обмена недоступен — пользователь может скопировать текст вручную */
    }
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const text = [
      `Здравствуйте, ${MANAGER}! Хочу купить баню-бочку «${MODEL}» ${SIZE} (2 секции) по акции за ${PRICE_DISPLAY}.`,
      name && `Меня зовут ${name.trim()}.`,
      phone && `Мой телефон: ${phone.trim()}.`,
      comment && `Комментарий: ${comment.trim()}`,
    ]
      .filter(Boolean)
      .join(" ");

    setMessage(text);
    // Дублируем текст в буфер обмена — на случай, если MAX откроется без предзаполненного сообщения.
    void copyMessage(text);
    window.open(maxUrl(text), "_blank", "noopener,noreferrer");
    setSent(true);
  };

  return (
    <Section id="contact" index={index} total={total} className="bg-coal-950 pb-10 lg:pb-12">
      <div className="absolute inset-0">
        <img src={IMAGES.hero} alt="" className="h-full w-full object-cover object-center opacity-40 saturate-75" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-b from-coal-950 via-coal-950/80 to-coal-950" />
        <div className="absolute inset-0 grain" />
      </div>

      <Container>
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <div>
            <Reveal>
              <Eyebrow>Контакты</Eyebrow>
              <Title>
                Успейте купить по акции
                <br />
                <span className="text-gradient-ember whitespace-nowrap">за {PRICE_DISPLAY}</span>
              </Title>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-cream-300 sm:text-lg">
                Позвоните или напишите {MANAGER_DATIVE} — он ответит на вопросы, поможет выбрать место на участке и
                зафиксирует акционную цену.
              </p>
            </Reveal>

            <Reveal delay={120}>
              <a
                href={PHONE_TEL}
                className="group mt-8 inline-flex max-w-full items-center gap-3 rounded-3xl border border-ember-400/30 bg-coal-900/70 p-3 pr-5 backdrop-blur transition hover:border-ember-400/60 sm:gap-6 sm:p-5 sm:pr-9"
              >
                <span className="relative grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-ember-400 to-ember-600 text-coal-950 shadow-glow sm:h-16 sm:w-16">
                  <span className="absolute inset-0 rounded-full bg-ember-500 animate-pulse-ring" />
                  <PhoneIcon size={24} className="relative" />
                </span>
                <span className="min-w-0">
                  <span className="block whitespace-nowrap font-display text-lg font-bold tabular-nums tracking-tight text-cream-50 transition-colors group-hover:text-ember-300 min-[420px]:text-xl sm:text-3xl lg:text-4xl">
                    {PHONE_DISPLAY}
                  </span>
                  <span className="mt-1 block text-sm text-cream-400">
                    {MANAGER} · {COMPANY} · ежедневно
                  </span>
                </span>
              </a>
            </Reveal>

            <Reveal delay={220}>
              <div className="mt-6 flex flex-wrap gap-3">
                <ButtonLink href={maxUrl()} target="_blank" rel="noopener noreferrer" variant="max">
                  <MaxIcon size={18} />
                  Написать в {MAX_NAME}
                </ButtonLink>
                <ButtonLink href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer" variant="ghost">
                  <TelegramIcon size={18} />
                  Telegram
                </ButtonLink>
                <ButtonLink href={PHONE_TEL} variant="outline">
                  <PhoneIcon size={16} />
                  Позвонить
                </ButtonLink>
              </div>
            </Reveal>

            <Reveal delay={320}>
              <ul className="mt-10 grid gap-4 sm:grid-cols-3">
                {[
                  { Icon: ClockIcon, t: "Фиксируем цену", d: "сразу при заказе" },
                  { Icon: TruckIcon, t: "Доставка", d: "готовой бани на участок" },
                  { Icon: ShieldIcon, t: "Гарантия", d: "на конструкцию и монтаж" },
                ].map(({ Icon, t, d }) => (
                  <li key={t} className="flex items-center gap-3 text-sm">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-cream-50/10 bg-coal-900/70 text-ember-300">
                      <Icon size={18} />
                    </span>
                    <span>
                      <span className="block font-semibold text-cream-50">{t}</span>
                      <span className="text-cream-400">{d}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <form
              onSubmit={submit}
              className="relative overflow-hidden rounded-3xl border border-cream-50/10 bg-coal-900/80 p-6 shadow-card backdrop-blur-xl sm:p-8"
            >
              <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-ember-500/15 blur-3xl" />
              <h3 className="font-display text-xl font-semibold text-cream-50">Оставить заявку</h3>
              <p className="mt-2 text-sm text-cream-400">
                Заполните форму — мы откроем {MAX_NAME} с готовым сообщением для {MANAGER_DATIVE}.
              </p>

              {sent ? (
                <div className="mt-6 rounded-2xl border border-ember-400/40 bg-ember-400/10 p-5">
                  <div className="flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-full bg-ember-500 text-coal-950">
                      <CheckIcon size={16} />
                    </span>
                    <div className="font-semibold text-cream-50">Сообщение готово — открываем {MAX_NAME}</div>
                  </div>

                  <p className="mt-3 text-sm leading-relaxed text-cream-300">
                    {MAX_PROFILE_URL ? (
                      <>Откроется чат с {MANAGER_DATIVE} — отправьте сообщение.</>
                    ) : (
                      <>
                        В {MAX_NAME} выберите чат с {MANAGER_DATIVE} — его легко найти по номеру{" "}
                        <span className="whitespace-nowrap font-semibold text-cream-50">{PHONE_DISPLAY}</span>. Текст уже
                        скопирован в буфер обмена.
                      </>
                    )}
                  </p>

                  <div className="mt-4 rounded-xl border border-cream-50/10 bg-coal-950/70 p-3.5 text-xs leading-relaxed text-cream-300">
                    {message}
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <ButtonLink href={maxUrl(message)} target="_blank" rel="noopener noreferrer" variant="max">
                      <MaxIcon size={16} />
                      Открыть {MAX_NAME} ещё раз
                    </ButtonLink>
                    <Button variant="outline" onClick={() => copyMessage(message)}>
                      {copied ? <CheckIcon size={16} className="text-ember-300" /> : <CopyIcon size={16} />}
                      {copied ? "Скопировано" : "Скопировать текст"}
                    </Button>
                  </div>

                  <p className="mt-4 text-xs leading-relaxed text-cream-400">
                    Если {MAX_NAME} не открылся — просто позвоните:{" "}
                    <a href={PHONE_TEL} className="font-semibold text-ember-300">
                      {PHONE_DISPLAY}
                    </a>
                  </p>
                  <button type="button" onClick={() => setSent(false)} className="mt-3 text-xs text-cream-500 underline-offset-4 hover:text-cream-200 hover:underline">
                    Заполнить заново
                  </button>
                </div>
              ) : (
                <div className="mt-6 space-y-4">
                  <Field label="Ваше имя">
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Например, Сергей"
                      className={inputCls}
                      autoComplete="name"
                    />
                  </Field>
                  <Field label="Телефон">
                    <input
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+7 (___) ___-__-__"
                      className={inputCls}
                      type="tel"
                      inputMode="tel"
                      autoComplete="tel"
                      required
                    />
                  </Field>
                  <Field label="Комментарий (необязательно)">
                    <textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Регион доставки, нужна ли печь, удобное время звонка…"
                      rows={3}
                      className={`${inputCls} resize-none`}
                    />
                  </Field>
                  <Button type="submit" size="lg" variant="max" className="w-full">
                    <MaxIcon size={18} />
                    Отправить в {MAX_NAME}
                  </Button>
                  <p className="text-center text-[11px] leading-relaxed text-cream-500">
                    Нажимая кнопку, вы соглашаетесь на обработку персональных данных.
                  </p>
                </div>
              )}
            </form>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}

const inputCls =
  "w-full rounded-xl border border-cream-50/10 bg-coal-950/70 px-4 py-3 text-sm text-cream-50 placeholder:text-cream-500 transition focus:border-ember-400/60 focus:outline-none focus:ring-2 focus:ring-ember-400/30";

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.18em] text-cream-500">{label}</span>
      {children}
    </label>
  );
}
