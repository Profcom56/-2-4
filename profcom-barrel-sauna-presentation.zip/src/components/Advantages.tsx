import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { ADVANTAGE_ICONS, type AdvantageIconName } from "@/components/ui/Icons";
import { ADVANTAGES, MODEL } from "@/data/content";
import { IMAGES } from "@/data/images";

export function Advantages({ index, total }: { index: number; total: number }) {
  return (
    <Section id="advantages" index={index} total={total} className="bg-coal-900">
      {/* Фоновое фото */}
      <div className="pointer-events-none absolute inset-0">
        <img src={IMAGES.shingle} alt="" className="h-full w-full object-cover opacity-20" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-b from-coal-900 via-coal-900/80 to-coal-900" />
        <div className="absolute inset-0 bg-gradient-to-r from-coal-900 via-transparent to-coal-900" />
      </div>

      <Container>
        <Reveal>
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <Eyebrow>Почему «{MODEL}»</Eyebrow>
              <Title>
                Баня, которую
                <br />
                <span className="text-gradient-ember">выбирают сердцем</span>
              </Title>
            </div>
            <Lead className="mt-0 md:max-w-md md:text-right">
              Форма «Квадро» объединила лучшее от классической бочки и полноценной бани: быстрый прогрев, мобильность
              и настоящий простор внутри.
            </Lead>
          </div>
        </Reveal>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ADVANTAGES.map((a, i) => {
            const Icon = ADVANTAGE_ICONS[a.icon as AdvantageIconName];
            return (
              <Reveal key={a.title} delay={i * 70}>
                <article className="group relative h-full overflow-hidden rounded-3xl border border-cream-50/10 bg-coal-950/60 p-6 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-ember-400/40 sm:p-7">
                  <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-ember-500/0 blur-2xl transition-all duration-500 group-hover:bg-ember-500/20" />
                  <div className="flex items-center justify-between">
                    <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-ember-400/20 to-ember-600/10 text-ember-300 ring-1 ring-ember-400/30">
                      <Icon size={22} />
                    </span>
                    <span className="font-display text-xs text-cream-500">0{i + 1}</span>
                  </div>
                  <h3 className="mt-5 font-display text-lg font-semibold text-cream-50">{a.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-cream-300">{a.text}</p>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-6 grid overflow-hidden rounded-3xl border border-cream-50/10 bg-coal-950/70 backdrop-blur-sm md:grid-cols-3">
            <div className="border-b border-cream-50/10 p-6 md:border-b-0 md:border-r">
              <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cream-500">Сравнение</div>
              <div className="mt-2 font-display text-lg font-semibold text-cream-50">«Квадро» против круглой бочки</div>
            </div>
            {[
              { k: "Полезный объём", q: "+ 20–25 %", r: "ограничен скруглением стен" },
              { k: "Расстановка", q: "полки и печь по прямым стенам", r: "теряется место у пола и потолка" },
            ].map((row) => (
              <div key={row.k} className="border-b border-cream-50/10 p-6 last:border-b-0 md:border-b-0 md:border-r md:last:border-r-0">
                <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cream-500">{row.k}</div>
                <div className="mt-2 flex items-center gap-2 text-sm font-semibold text-ember-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-ember-400" /> Квадро: {row.q}
                </div>
                <div className="mt-1 flex items-center gap-2 text-sm text-cream-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-cream-500/50" /> Круглая: {row.r}
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </Container>
    </Section>
  );
}
