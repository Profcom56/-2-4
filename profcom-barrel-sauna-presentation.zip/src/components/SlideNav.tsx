import { SLIDES } from "@/data/content";
import { scrollToSection } from "@/hooks/useSlideKeyboard";
import { cn } from "@/utils/cn";

export function SlideNav({ activeId }: { activeId: string }) {
  const activeIndex = Math.max(0, SLIDES.findIndex((s) => s.id === activeId));

  return (
    <nav
      className="fixed right-5 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-end gap-3 lg:flex"
      aria-label="Навигация по слайдам"
    >
      {SLIDES.map((s, i) => {
        const active = s.id === activeId;
        return (
          <button
            key={s.id}
            onClick={() => scrollToSection(s.id)}
            className="group flex items-center gap-3"
            aria-label={`Слайд ${i + 1}: ${s.label}`}
            aria-current={active ? "true" : undefined}
          >
            <span
              className={cn(
                "translate-x-2 rounded-full border border-cream-50/10 bg-coal-900/80 px-2.5 py-1 text-[11px] font-medium text-cream-300 opacity-0 backdrop-blur transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100",
                active && "text-ember-300",
              )}
            >
              {s.label}
            </span>
            <span
              className={cn(
                "block rounded-full transition-all duration-300",
                active ? "h-7 w-1.5 bg-ember-400 shadow-glow" : "h-1.5 w-1.5 bg-cream-50/30 group-hover:bg-cream-50/70",
              )}
            />
          </button>
        );
      })}
      <div className="mt-2 font-display text-[10px] tabular-nums tracking-[0.2em] text-cream-500">
        {String(activeIndex + 1).padStart(2, "0")}
      </div>
    </nav>
  );
}
