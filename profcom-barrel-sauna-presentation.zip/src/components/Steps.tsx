import { useState } from "react";
import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { PhoneIcon, PlusIcon } from "@/components/ui/Icons";
import { FAQ, MANAGER_DATIVE, PHONE_TEL, STEPS } from "@/data/content";
import { IMAGES } from "@/data/images";
import { cn } from "@/utils/cn";

export function Steps({ index, total }: { index: number; total: number }) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <Section id="steps" index={index} total={total} className="bg-coal-950 wood-lines">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[1fr_0.9fr] lg:gap-16">
          <div>
            <Reveal>
              <Eyebrow>Как купить</Eyebrow>
              <Title>
                Пять шагов
                <br />
                <span className="text-cream-400">до первого пара</span>
              </Title>
              <Lead>Вам не нужно ничего строить и согласовывать. Мы делаем всё сами — вы только выбираете место на участке.</Lead>
            </Reveal>

            <ol className="relative mt-8 space-y-0">
              <span className="absolute bottom-6 left-[29px] top-6 w-px bg-gradient-to-b from-ember-400 via-ember-500/40 to-transparent" />
              {STEPS.map((s, i) => (
                <Reveal key={s.num} delay={i * 80} as="li">
                  <div className="group relative flex gap-5 rounded-2xl px-3 py-2.5 transition-colors hover:bg-cream-50/[0.03]">
                    <span
                      className={cn(
                        "relative z-10 grid h-9 w-9 shrink-0 place-items-center rounded-full border font-display text-xs font-semibold transition-all",
                        i === 0
                          ? "border-ember-400 bg-ember-500 text-coal-950 shadow-glow"
                          : "border-cream-50/15 bg-coal-900 text-ember-300 group-hover:border-ember-400/60",
                      )}
                    >
                      {s.num}
                    </span>
                    <div className="pt-1.5">
                      <h3 className="font-display text-base font-semibold text-cream-50 sm:text-lg">{s.title}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-cream-300">{s.text}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </ol>

            <Reveal delay={450}>
              <div className="mt-8">
                <ButtonLink href={PHONE_TEL} size="lg">
                  <PhoneIcon size={18} />
                  Сделать первый шаг — позвонить {MANAGER_DATIVE}
                </ButtonLink>
              </div>
            </Reveal>
          </div>

          <div className="space-y-6">
            <Reveal delay={150}>
              <div className="relative overflow-hidden rounded-3xl border border-cream-50/10 shadow-card">
                <img src={IMAGES.delivery} alt="Доставка готовой бани-бочки Квадро манипулятором" className="aspect-[16/10] w-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-coal-950/90 via-coal-950/10 to-transparent" />
                <div className="absolute bottom-5 left-6 right-6">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-ember-300">Доставка</div>
                  <div className="mt-1 font-display text-lg font-semibold text-cream-50 sm:text-xl">
                    Привозим собранную баню манипулятором и ставим на место за несколько часов
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={250}>
              <div className="rounded-3xl border border-cream-50/10 bg-coal-900/70 p-2">
                {FAQ.map((f, i) => {
                  const open = openFaq === i;
                  return (
                    <div key={f.q} className="border-b border-cream-50/10 last:border-b-0">
                      <button
                        onClick={() => setOpenFaq(open ? null : i)}
                        className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left transition-colors hover:text-ember-300"
                        aria-expanded={open}
                      >
                        <span className="text-sm font-semibold text-cream-50 sm:text-base">{f.q}</span>
                        <span
                          className={cn(
                            "grid h-7 w-7 shrink-0 place-items-center rounded-full border border-cream-50/15 text-cream-300 transition-transform duration-300",
                            open && "rotate-45 border-ember-400/60 text-ember-300",
                          )}
                        >
                          <PlusIcon size={14} />
                        </span>
                      </button>
                      <div
                        className={cn(
                          "grid transition-all duration-400 ease-out",
                          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                        )}
                      >
                        <div className="overflow-hidden">
                          <p className="px-4 pb-4 text-sm leading-relaxed text-cream-300">{f.a}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </Section>
  );
}
