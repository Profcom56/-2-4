import { useCallback, useEffect, useRef } from "react";
import { GALLERY, focusStyle } from "@/data/images";
import { ChevronLeftIcon, ChevronRightIcon, CloseIcon } from "@/components/ui/Icons";

type LightboxProps = {
  index: number | null;
  onClose: () => void;
  onChange: (next: number) => void;
};

export function Lightbox({ index, onClose, onChange }: LightboxProps) {
  const touchStartX = useRef<number | null>(null);
  const open = index !== null;
  const count = GALLERY.length;

  const prev = useCallback(() => {
    if (index === null) return;
    onChange((index - 1 + count) % count);
  }, [index, count, onChange]);

  const next = useCallback(() => {
    if (index === null) return;
    onChange((index + 1) % count);
  }, [index, count, onChange]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [open, onClose, prev, next]);

  if (index === null) return null;
  const item = GALLERY[index];

  return (
    <div
      className="fixed inset-0 z-[80] flex flex-col bg-coal-950/95 backdrop-blur-xl"
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      onClick={onClose}
      onTouchStart={(e) => {
        touchStartX.current = e.touches[0].clientX;
      }}
      onTouchEnd={(e) => {
        if (touchStartX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchStartX.current;
        if (Math.abs(dx) > 50) (dx < 0 ? next : prev)();
        touchStartX.current = null;
      }}
    >
      <div className="flex items-center justify-between px-5 py-4 sm:px-8">
        <div className="text-sm text-cream-400">
          <span className="font-display text-cream-50">{String(index + 1).padStart(2, "0")}</span> / {String(count).padStart(2, "0")}
        </div>
        <button
          onClick={onClose}
          className="grid h-11 w-11 place-items-center rounded-full border border-cream-50/15 text-cream-50 transition hover:border-ember-400/60 hover:text-ember-300"
          aria-label="Закрыть"
        >
          <CloseIcon size={22} />
        </button>
      </div>

      <div className="relative flex flex-1 items-center justify-center px-4 pb-6 sm:px-20">
        <button
          onClick={(e) => {
            e.stopPropagation();
            prev();
          }}
          className="absolute left-3 top-1/2 z-10 hidden h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-cream-50/15 bg-coal-900/70 text-cream-50 transition hover:border-ember-400/60 hover:text-ember-300 sm:grid lg:left-8"
          aria-label="Предыдущее фото"
        >
          <ChevronLeftIcon size={24} />
        </button>

        <figure className="flex max-h-full w-full max-w-6xl flex-col items-center" onClick={(e) => e.stopPropagation()}>
          {item.focus ? (
            <div
              key={`${item.src}-${index}`}
              className="aspect-[3/2] h-[min(70vh,60vw)] max-w-full overflow-hidden rounded-2xl shadow-card animate-[fadeIn_.4s_ease]"
            >
              <img src={item.src} alt={item.alt} className="h-full w-full object-cover" style={focusStyle(item.focus)} />
            </div>
          ) : (
            <img
              key={`${item.src}-${index}`}
              src={item.src}
              alt={item.alt}
              className="max-h-[70vh] w-auto max-w-full rounded-2xl object-contain shadow-card animate-[fadeIn_.4s_ease]"
            />
          )}
          <figcaption className="mt-4 flex flex-wrap items-center justify-center gap-3 text-center">
            <span className="rounded-full border border-ember-400/40 bg-ember-400/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-ember-300">
              {item.tag}
            </span>
            <span className="font-display text-base text-cream-50 sm:text-lg">{item.title}</span>
          </figcaption>
        </figure>

        <button
          onClick={(e) => {
            e.stopPropagation();
            next();
          }}
          className="absolute right-3 top-1/2 z-10 hidden h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-cream-50/15 bg-coal-900/70 text-cream-50 transition hover:border-ember-400/60 hover:text-ember-300 sm:grid lg:right-8"
          aria-label="Следующее фото"
        >
          <ChevronRightIcon size={24} />
        </button>
      </div>

      {/* Миниатюры */}
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-5 pb-5 sm:justify-center sm:px-8" onClick={(e) => e.stopPropagation()}>
        {GALLERY.map((g, i) => (
          <button
            key={g.src + i}
            onClick={() => onChange(i)}
            className={`h-14 w-20 shrink-0 overflow-hidden rounded-lg border transition ${
              i === index ? "border-ember-400 opacity-100" : "border-transparent opacity-50 hover:opacity-90"
            }`}
            aria-label={`Фото ${i + 1}: ${g.title}`}
          >
            <img src={g.src} alt="" className="h-full w-full object-cover" style={focusStyle(g.focus)} />
          </button>
        ))}
      </div>
    </div>
  );
}
