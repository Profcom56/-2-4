import { useState } from "react";
import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { IMAGES } from "@/data/images";
import { cn } from "@/utils/cn";

type Room = "rest" | "steam";

const ROOMS: Record<Room, { title: string; size: string; items: string[]; image: string }> = {
  rest: {
    title: "Предбанник",
    size: "2,0 × 2,0 м",
    items: ["Пластиковая входная дверь", "Лавка-диван с подушками", "Столик для чая", "Окно с видом на участок", "Вешалки и полка для вещей"],
    image: IMAGES.rest,
  },
  steam: {
    title: "Парная",
    size: "2,0 × 2,0 м",
    items: ["Дровяная печь-каменка", "Полки в два яруса", "Окно для света и проветривания", "Дверь в парную", "Термогигрометр"],
    image: IMAGES.steam,
  },
};

const EMBER = "#f7b538";
const WOOD = "#c69c66";
const PVC = "#f4f6f8"; // белый пластик входной двери
const LINE = "rgba(248,241,230,0.35)";
const TEXT = "#d2c4af";

export function FloorPlan({ index, total }: { index: number; total: number }) {
  const [room, setRoom] = useState<Room>("steam");

  const roomFill = (r: Room) => (room === r ? "rgba(247,181,56,0.14)" : "rgba(248,241,230,0.03)");
  const roomStroke = (r: Room) => (room === r ? EMBER : "rgba(248,241,230,0.18)");

  return (
    <Section id="plan" index={index} total={total} className="bg-coal-950 wood-lines">
      <Container>
        <Reveal>
          <Eyebrow>Планировка</Eyebrow>
          <Title>
            Две секции —
            <br />
            <span className="text-cream-400">парная и предбанник</span>
          </Title>
          <Lead>
            Четыре метра длины делятся пополам: два метра на жаркую парную и два — на комнату отдыха, где можно
            переодеться и выпить чай между заходами.
          </Lead>
        </Reveal>

        <div className="mt-10 grid items-stretch gap-6 lg:grid-cols-[1.35fr_1fr]">
          <Reveal delay={120}>
            <div className="h-full rounded-3xl border border-cream-50/10 bg-coal-900/70 p-4 shadow-card sm:p-6">
              <div className="mb-3 flex items-center justify-between text-xs text-cream-500">
                <span className="font-semibold uppercase tracking-[0.2em]">Вид сверху · масштаб 1 : 100</span>
                <span className="hidden sm:inline">нажмите на секцию</span>
              </div>
              <svg viewBox="0 0 560 330" className="w-full" role="img" aria-label="Планировка бани-бочки Квадро 2 на 4 метра">
                {/* Размер 4 м */}
                <g stroke={LINE} strokeWidth="1">
                  <line x1="80" y1="36" x2="480" y2="36" />
                  <line x1="80" y1="30" x2="80" y2="42" />
                  <line x1="480" y1="30" x2="480" y2="42" />
                  <line x1="280" y1="30" x2="280" y2="42" />
                </g>
                <text x="180" y="28" textAnchor="middle" fill={TEXT} fontSize="12" fontFamily="Manrope, sans-serif">2,0 м</text>
                <text x="380" y="28" textAnchor="middle" fill={TEXT} fontSize="12" fontFamily="Manrope, sans-serif">2,0 м</text>
                <text x="280" y="14" textAnchor="middle" fill={EMBER} fontSize="13" fontWeight="700" fontFamily="Manrope, sans-serif">
                  4,0 м
                </text>

                {/* Размер 2 м */}
                <g stroke={LINE} strokeWidth="1">
                  <line x1="52" y1="60" x2="52" y2="260" />
                  <line x1="46" y1="60" x2="58" y2="60" />
                  <line x1="46" y1="260" x2="58" y2="260" />
                </g>
                <text
                  x="40"
                  y="160"
                  textAnchor="middle"
                  fill={EMBER}
                  fontSize="13"
                  fontWeight="700"
                  fontFamily="Manrope, sans-serif"
                  transform="rotate(-90 40 160)"
                >
                  2,0 м
                </text>

                {/* Корпус */}
                <rect x="80" y="60" width="400" height="200" rx="22" fill="rgba(198,156,102,0.08)" stroke={WOOD} strokeWidth="6" />

                {/* Предбанник */}
                <g className="cursor-pointer" onClick={() => setRoom("rest")} onMouseEnter={() => setRoom("rest")}>
                  <path
                    d="M102 60 H280 V260 H102 A22 22 0 0 1 80 238 V82 A22 22 0 0 1 102 60 Z"
                    fill={roomFill("rest")}
                    stroke={roomStroke("rest")}
                    strokeWidth="2"
                    className="transition-all duration-300"
                  />
                  {/* Лавка */}
                  <rect x="100" y="196" width="160" height="48" rx="6" fill="rgba(198,156,102,0.35)" stroke={WOOD} strokeWidth="1.5" />
                  <line x1="100" y1="212" x2="260" y2="212" stroke={WOOD} strokeWidth="1" opacity="0.6" />
                  {/* Столик */}
                  <circle cx="200" cy="140" r="22" fill="rgba(198,156,102,0.25)" stroke={WOOD} strokeWidth="1.5" />
                  {/* Окно */}
                  <rect x="140" y="56" width="60" height="8" rx="2" fill="#13100d" stroke={EMBER} strokeWidth="1.5" />
                  {/* Вешалки */}
                  {[120, 132, 144].map((x) => (
                    <circle key={x} cx={x} cy="84" r="2.5" fill={WOOD} />
                  ))}
                  {/* Пластиковая входная дверь (белая) */}
                  <path d="M80 150 A70 70 0 0 1 150 220" fill="none" stroke={PVC} strokeWidth="1" strokeDasharray="3 3" />
                  <line x1="80" y1="150" x2="150" y2="150" stroke={PVC} strokeWidth="3.5" strokeLinecap="round" />
                  <text x="180" y="105" textAnchor="middle" fill={room === "rest" ? "#f8f1e6" : TEXT} fontSize="13" fontWeight="700" fontFamily="Unbounded, Manrope, sans-serif">
                    Предбанник
                  </text>
                </g>

                {/* Перегородка */}
                <line x1="280" y1="60" x2="280" y2="260" stroke={WOOD} strokeWidth="5" />
                {/* Дверь в парную (деревянная) */}
                <rect x="276" y="140" width="8" height="70" fill="#13100d" />
                <line x1="280" y1="140" x2="280" y2="210" stroke={WOOD} strokeWidth="3" strokeLinecap="round" />
                <path d="M280 140 A70 70 0 0 1 350 210" fill="none" stroke={WOOD} strokeWidth="1" strokeDasharray="3 3" />

                {/* Парная */}
                <g className="cursor-pointer" onClick={() => setRoom("steam")} onMouseEnter={() => setRoom("steam")}>
                  <path
                    d="M280 60 H458 A22 22 0 0 1 480 82 V238 A22 22 0 0 1 458 260 H280 Z"
                    fill={roomFill("steam")}
                    stroke={roomStroke("steam")}
                    strokeWidth="2"
                    className="transition-all duration-300"
                  />
                  {/* Полки */}
                  <rect x="300" y="186" width="170" height="58" rx="6" fill="rgba(198,156,102,0.35)" stroke={WOOD} strokeWidth="1.5" />
                  <rect x="300" y="160" width="170" height="26" rx="4" fill="rgba(198,156,102,0.5)" stroke={WOOD} strokeWidth="1.5" />
                  {/* Печь */}
                  <rect x="426" y="76" width="44" height="44" rx="6" fill="#26201a" stroke={EMBER} strokeWidth="2" />
                  <circle cx="448" cy="98" r="12" fill="rgba(247,181,56,0.25)" stroke={EMBER} strokeWidth="1.5" />
                  <circle cx="448" cy="98" r="4" fill={EMBER}>
                    <animate attributeName="opacity" values="1;0.4;1" dur="1.6s" repeatCount="indefinite" />
                  </circle>
                  {/* Окно */}
                  <rect x="350" y="56" width="50" height="8" rx="2" fill="#13100d" stroke={EMBER} strokeWidth="1.5" />
                  <text x="375" y="140" textAnchor="middle" fill={room === "steam" ? "#f8f1e6" : TEXT} fontSize="13" fontWeight="700" fontFamily="Unbounded, Manrope, sans-serif">
                    Парная
                  </text>
                </g>

                {/* Крыльцо */}
                <rect x="40" y="170" width="36" height="60" rx="4" fill="rgba(198,156,102,0.2)" stroke={WOOD} strokeWidth="1" strokeDasharray="4 3" />
                <text x="58" y="245" textAnchor="middle" fill={TEXT} fontSize="9" fontFamily="Manrope, sans-serif">вход</text>

                {/* Легенда */}
                <g fontFamily="Manrope, sans-serif" fontSize="11" fill={TEXT}>
                  <rect x="80" y="292" width="14" height="10" rx="2" fill="rgba(198,156,102,0.4)" stroke={WOOD} strokeWidth="1" />
                  <text x="100" y="301">полки / лавка</text>
                  <rect x="196" y="292" width="14" height="10" rx="2" fill="#26201a" stroke={EMBER} strokeWidth="1.5" />
                  <text x="216" y="301">печь-каменка</text>
                  <rect x="300" y="294" width="14" height="6" rx="1" fill="#13100d" stroke={EMBER} strokeWidth="1.2" />
                  <text x="320" y="301">окно</text>
                  <line x1="358" y1="297" x2="374" y2="297" stroke={PVC} strokeWidth="2.5" strokeLinecap="round" />
                  <text x="380" y="301">пластиковая дверь</text>
                  <line x1="482" y1="297" x2="498" y2="297" stroke={WOOD} strokeWidth="2.5" strokeLinecap="round" />
                  <text x="504" y="301">в парную</text>
                </g>
              </svg>
            </div>
          </Reveal>

          <Reveal delay={220}>
            <div className="flex h-full flex-col overflow-hidden rounded-3xl border border-cream-50/10 bg-coal-900/70 shadow-card">
              <div className="flex gap-1 p-2">
                {(Object.keys(ROOMS) as Room[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setRoom(r)}
                    className={cn(
                      "flex-1 rounded-2xl px-4 py-2.5 text-sm font-semibold transition-all",
                      room === r ? "bg-ember-500 text-coal-950 shadow-glow" : "text-cream-300 hover:bg-cream-50/5",
                    )}
                  >
                    {ROOMS[r].title}
                  </button>
                ))}
              </div>
              <div className="relative aspect-[16/10] overflow-hidden">
                {(Object.keys(ROOMS) as Room[]).map((r) => (
                  <img
                    key={r}
                    src={ROOMS[r].image}
                    alt={ROOMS[r].title}
                    loading="lazy"
                    className={cn(
                      "absolute inset-0 h-full w-full object-cover transition-all duration-700",
                      room === r ? "scale-100 opacity-100" : "scale-105 opacity-0",
                    )}
                  />
                ))}
                <div className="absolute inset-0 bg-gradient-to-t from-coal-900 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-5">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-ember-300">{ROOMS[room].size}</div>
                  <div className="font-display text-2xl font-semibold text-cream-50">{ROOMS[room].title}</div>
                </div>
              </div>
              <ul className="grid flex-1 gap-2 p-5 sm:p-6">
                {ROOMS[room].items.map((item, i) => (
                  <li key={item} className="flex items-center gap-3 text-sm text-cream-200" style={{ animation: `fadeIn .4s ease ${i * 60}ms both` }}>
                    <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-ember-400" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}
