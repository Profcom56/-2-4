import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

type SectionProps = {
  id: string;
  children: ReactNode;
  className?: string;
  /** Номер слайда для подписи в углу */
  index?: number;
  total?: number;
};

export function Section({ id, children, className, index, total }: SectionProps) {
  return (
    <section
      id={id}
      className={cn(
        "snap-slide relative flex min-h-[100svh] flex-col justify-center overflow-hidden py-24 lg:py-24",
        className,
      )}
    >
      {typeof index === "number" && typeof total === "number" && (
        <div className="pointer-events-none absolute right-6 top-24 hidden select-none font-display text-xs tracking-[0.3em] text-cream-500/60 lg:block">
          {String(index).padStart(2, "0")} / {String(total).padStart(2, "0")}
        </div>
      )}
      {children}
    </section>
  );
}

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("relative z-10 mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-12", className)}>{children}</div>;
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "inline-flex items-center gap-3 font-display text-[11px] font-medium uppercase tracking-[0.3em] text-ember-400",
        className,
      )}
    >
      <span className="h-px w-8 bg-ember-500/70" />
      {children}
    </div>
  );
}

export function Title({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <h2
      className={cn(
        "mt-4 font-display text-3xl font-semibold leading-[1.1] tracking-tight text-cream-50 text-balance sm:text-4xl lg:text-[2.75rem] xl:text-5xl",
        className,
      )}
    >
      {children}
    </h2>
  );
}

export function Lead({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("mt-4 max-w-2xl text-base leading-relaxed text-cream-300 sm:text-lg", className)}>{children}</p>;
}
