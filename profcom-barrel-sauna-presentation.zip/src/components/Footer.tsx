import { Logo } from "@/components/ui/Logo";
import { COMPANY, MANAGER, MODEL, PHONE_DISPLAY, PHONE_TEL, PRICE_DISPLAY, SIZE } from "@/data/content";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative border-t border-cream-50/10 bg-coal-950 py-8">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 px-5 sm:px-8 md:flex-row md:items-center md:justify-between lg:px-12">
        <Logo />
        <p className="max-w-md text-xs leading-relaxed text-cream-500">
          Баня-бочка «{MODEL}» {SIZE}, 2 секции — {PRICE_DISPLAY} по акции. Предложение ограничено, не является публичной
          офертой. Комплектацию и сроки уточняйте у менеджера.
        </p>
        <div className="text-sm text-cream-400">
          <a href={PHONE_TEL} className="font-semibold text-cream-50 hover:text-ember-300">
            {PHONE_DISPLAY}
          </a>{" "}
          — {MANAGER}
          <div className="mt-1 text-xs text-cream-500">
            © {year} {COMPANY}
          </div>
        </div>
      </div>
    </footer>
  );
}
