import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { CheckIcon, MaxIcon, PhoneIcon, PlusIcon } from "@/components/ui/Icons";
import { useCountdown } from "@/hooks/useCountdown";
import { INCLUDED, MANAGER_DATIVE, MAX_NAME, MODEL, OPTIONS, PHONE_TEL, PRICE_DISPLAY, SIZE, maxUrl } from "@/data/content";
import { IMAGES } from "@/data/images";

const pad = (n: number) => String(n).padStart(2, "0");

function CountdownBlock() {
  const { days, hours, minutes, seconds } = useCountdown();
  const cells = [
    { v: pad(days), l: "дней" },
    { v: pad(hours), l: "часов" },
    { v: pad(minutes), l: "минут" },
    { v: pad(seconds), l: "секунд" },
  ];
  return (
    <div>
      <div className="text-[11px] font-semibold uppercase tracking-[0.25em] text-cream-500">До конца акции</div>
      <div className="mt-3 grid grid-cols-4 gap-2 sm:flex sm:items-center">
        {cells.map((c, i) => (
          <div key={c.l} className="flex min-w-0 items-center gap-2">
            <div className="flex min-w-0 flex-1 flex-col items-center rounded-xl border border-cream-50/10 bg-coal-950/60 px-1 py-2.5 sm:min-w-[64px] sm:flex-none sm:px-3">
              <span className="font-display text-xl font-semibold tabular-nums text-cream-50 sm:text-2xl">{c.v}</span>
              <span className="mt-0.5 text-[9px] uppercase tracking-[0.12em] text-cream-500 sm:text-[10px] sm:tracking-[0.15em]">{c.l}</span>
            </div>
            {i < cells.length - 1 && <span className="-mt-4 hidden font-display text-xl text-ember-500 sm:inline">:</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Promo({ index, total }: { index: number; total: number }) {
  return (
    <Section id="promo" index={index} total={total} className="bg-coal-900 wood-lines">
      <div className="pointer-events-none absolute -left-40 top-1/3 h-[520px] w-[520px] rounded-full bg-ember-600/10 blur-[140px]" />
      <Container>
        <div className="grid items-start gap-12 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
          {/* Левая колонка */}
          <div>
            <Reveal>
              <Eyebrow>Специальное предложение</Eyebrow>
              <Title>
                Успей купить баню
                <br />
                <span className="text-gradient-ember">по акции</span>
              </Title>
              <Lead>
                Баня-бочка «{MODEL}» {SIZE} с двумя секциями — парной и предбанником — по фиксированной цене.
                Предложение действует на ограниченную партию.
              </Lead>
            </Reveal>

            <Reveal delay={120}>
              <div className="relative mt-8 overflow-hidden rounded-3xl border border-ember-400/30 bg-gradient-to-br from-coal-800 via-coal-900 to-coal-950 p-5 shadow-card sm:p-8">
                <div className="pointer-events-none absolute -right-20 -top-20 h-60 w-60 rounded-full bg-ember-500/20 blur-3xl" />
                <div className="relative flex flex-wrap items-end justify-between gap-6">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-[0.25em] text-ember-300">Цена по акции</div>
                    <div className="mt-2 whitespace-nowrap font-display text-[2.5rem] font-bold leading-none tracking-tight text-cream-50 sm:text-6xl lg:text-7xl">
                      {PRICE_DISPLAY}
                    </div>
                    <div className="mt-3 text-sm text-cream-400">за готовую баню {SIZE} · 2 секции · с установкой</div>
                  </div>
                  <div className="rounded-2xl border border-cream-50/10 bg-cream-50/5 px-4 py-3 text-center">
                    <div className="font-display text-2xl font-semibold text-ember-300">{SIZE}</div>
                    <div className="text-[11px] uppercase tracking-[0.2em] text-cream-500">2 секции</div>
                  </div>
                </div>

                <div className="relative mt-8 border-t border-cream-50/10 pt-6">
                  <CountdownBlock />
                </div>

                <div className="relative mt-8 flex flex-col gap-3 sm:flex-row">
                  <ButtonLink href={PHONE_TEL} size="lg" className="flex-1">
                    <PhoneIcon size={18} />
                    Позвонить {MANAGER_DATIVE}
                  </ButtonLink>
                  <ButtonLink href={maxUrl()} target="_blank" rel="noopener noreferrer" variant="max" size="lg" className="flex-1">
                    <MaxIcon size={18} />
                    Написать в {MAX_NAME}
                  </ButtonLink>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Правая колонка */}
          <div className="space-y-6">
            <Reveal delay={150}>
              <div className="overflow-hidden rounded-3xl border border-cream-50/10">
                <div className="relative aspect-[16/9]">
                  <img
                    src={IMAGES.shingleTerrace}
                    alt="Баня-бочка Квадро с мягкой крышей из гибкой черепицы на террасе"
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coal-950/80 to-transparent" />
                  <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between">
                    <div>
                      <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-ember-300">Модель</div>
                      <div className="font-display text-xl font-semibold text-cream-50">«{MODEL}» {SIZE}</div>
                    </div>
                    <div className="rounded-full bg-coal-950/70 px-3 py-1 text-xs text-cream-200 backdrop-blur">2 секции</div>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={250}>
              <div className="rounded-3xl border border-cream-50/10 bg-coal-800/50 p-6 sm:p-7">
                <h3 className="font-display text-lg font-semibold text-cream-50">Что входит в цену</h3>
                <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
                  {INCLUDED.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm leading-snug text-cream-200">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-ember-500/15 text-ember-400">
                        <CheckIcon size={12} />
                      </span>
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 border-t border-cream-50/10 pt-5">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cream-500">Дополнительно по желанию</div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {OPTIONS.map((o) => (
                      <span
                        key={o}
                        className="inline-flex items-center gap-1.5 rounded-full border border-cream-50/10 bg-cream-50/5 px-3 py-1.5 text-xs text-cream-300"
                      >
                        <PlusIcon size={12} className="text-ember-400" />
                        {o}
                      </span>
                    ))}
                  </div>
                </div>
                <p className="mt-5 text-xs leading-relaxed text-cream-500">
                  * Точную комплектацию, сроки изготовления и условия доставки уточняйте у менеджера по телефону.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </Container>
    </Section>
  );
}
