import { useEffect } from "react";

export function scrollToSection(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
}

/**
 * Навигация по слайдам клавишами: стрелки, PageUp/PageDown, Home/End.
 * Не перехватывает ввод в формах и не срабатывает при открытом лайтбоксе.
 */
export function useSlideKeyboard(ids: string[], activeId: string, enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;

    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;

      const index = Math.max(0, ids.indexOf(activeId));
      let next: number | null = null;

      switch (e.key) {
        case "ArrowDown":
        case "ArrowRight":
        case "PageDown":
          next = Math.min(ids.length - 1, index + 1);
          break;
        case "ArrowUp":
        case "ArrowLeft":
        case "PageUp":
          next = Math.max(0, index - 1);
          break;
        case "Home":
          next = 0;
          break;
        case "End":
          next = ids.length - 1;
          break;
        default:
          return;
      }

      if (next !== null && next !== index) {
        e.preventDefault();
        scrollToSection(ids[next]);
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [ids, activeId, enabled]);
}
