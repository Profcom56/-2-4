import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { MANAGER, NAV, PHONE_DISPLAY, PHONE_TEL } from "@/data/content";
import { Logo } from "@/components/ui/Logo";
import { CloseIcon, FullscreenIcon, MenuIcon, PhoneIcon } from "@/components/ui/Icons";
import { scrollToSection } from "@/hooks/useSlideKeyboard";

type HeaderProps = { activeId: string };

export function Header({ activeId }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await document.documentElement.requestFullscreen();
      }
    } catch {
      /* браузер не поддерживает — молча игнорируем */
    }
  };

  const go = (id: string) => {
    setOpen(false);
    scrollToSection(id);
  };

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled ? "glass shadow-card" : "bg-transparent",
        )}
      >
        <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8 lg:h-20 lg:px-12">
          <Logo />

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Разделы презентации">
            {NAV.map((item) => (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={cn(
                  "relative rounded-full px-3.5 py-2 text-sm font-medium text-cream-300 transition-colors hover:text-cream-50",
                  activeId === item.id && "text-ember-300",
                )}
              >
                {item.label}
                <span
                  className={cn(
                    "absolute inset-x-3.5 -bottom-0.5 h-px bg-ember-400 transition-transform duration-300",
                    activeId === item.id ? "scale-x-100" : "scale-x-0",
                  )}
                />
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleFullscreen}
              className="hidden h-10 w-10 place-items-center rounded-full border border-cream-50/10 text-cream-300 transition hover:border-ember-400/50 hover:text-ember-300 md:grid"
              title={isFullscreen ? "Выйти из полноэкранного режима" : "Режим презентации (на весь экран)"}
              aria-label="Режим презентации"
            >
              <FullscreenIcon size={18} />
            </button>

            <a
              href={PHONE_TEL}
              className="group hidden items-center gap-2.5 rounded-full border border-ember-400/40 bg-ember-400/10 py-2 pl-2 pr-4 text-sm font-semibold text-cream-50 transition hover:bg-ember-400/20 sm:inline-flex"
            >
              <span className="relative grid h-8 w-8 place-items-center rounded-full bg-ember-500 text-coal-950">
                <span className="absolute inset-0 rounded-full bg-ember-500 animate-pulse-ring" />
                <PhoneIcon size={15} className="relative" />
              </span>
              <span className="flex flex-col leading-none">
                <span className="tabular-nums">{PHONE_DISPLAY}</span>
                <span className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.2em] text-cream-400">{MANAGER}</span>
              </span>
            </a>

            <button
              onClick={() => setOpen(true)}
              className="grid h-10 w-10 place-items-center rounded-full border border-cream-50/10 text-cream-50 lg:hidden"
              aria-label="Открыть меню"
            >
              <MenuIcon size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Мобильное меню */}
      <div
        className={cn(
          "fixed inset-0 z-[60] flex flex-col bg-coal-950/95 backdrop-blur-xl transition-all duration-400 lg:hidden",
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
        )}
        aria-hidden={!open}
      >
        <div className="flex h-18 items-center justify-between px-5 sm:px-8">
          <Logo />
          <button
            onClick={() => setOpen(false)}
            className="grid h-10 w-10 place-items-center rounded-full border border-cream-50/10 text-cream-50"
            aria-label="Закрыть меню"
          >
            <CloseIcon size={20} />
          </button>
        </div>
        <nav className="flex flex-1 flex-col justify-center gap-1 px-8" aria-label="Мобильное меню">
          {NAV.map((item, i) => (
            <button
              key={item.id}
              onClick={() => go(item.id)}
              className={cn(
                "flex items-center gap-4 py-3 text-left font-display text-2xl font-semibold text-cream-100 transition-all",
                open ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0",
                activeId === item.id && "text-ember-300",
              )}
              style={{ transitionDelay: `${60 + i * 40}ms` }}
            >
              <span className="font-sans text-xs tabular-nums text-cream-500">0{i + 1}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="px-8 pb-10">
          <a
            href={PHONE_TEL}
            className="flex items-center justify-center gap-3 rounded-full bg-gradient-to-r from-ember-400 to-ember-600 px-6 py-4 font-semibold text-coal-950 shadow-glow"
          >
            <PhoneIcon size={18} />
            {PHONE_DISPLAY} — {MANAGER}
          </a>
        </div>
      </div>
    </>
  );
}
