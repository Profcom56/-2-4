import type { CSSProperties } from "react";
import hero from "@/assets/images/hero.jpg";
import steam from "@/assets/images/interior-steam.jpg";
import rest from "@/assets/images/interior-rest.jpg";
import delivery from "@/assets/images/delivery.jpg";
import shingle from "@/assets/images/shingle-roof.jpg";
import shingleTerrace from "@/assets/images/shingle-roof-2.jpg";

export const IMAGES = { hero, steam, rest, delivery, shingle, shingleTerrace };

/**
 * «Виртуальный» кадр: показываем фрагмент исходного фото.
 * x, y — положение фрагмента в процентах (как object-position), zoom — увеличение.
 */
export type Focus = { x: number; y: number; zoom: number };

export function focusStyle(focus?: Focus): CSSProperties | undefined {
  if (!focus) return undefined;
  const origin = `${focus.x}% ${focus.y}%`;
  return { objectPosition: origin, transformOrigin: origin, transform: `scale(${focus.zoom})` };
}

export type GalleryItem = {
  src: string;
  alt: string;
  title: string;
  tag: string;
  span?: "wide" | "tall";
  focus?: Focus;
};

export const GALLERY: GalleryItem[] = [
  {
    src: shingle,
    alt: "Баня-бочка Квадро с крышей из гибкой черепицы и пластиковой входной дверью",
    title: "Крыша из гибкой черепицы и пластиковая входная дверь",
    tag: "Кровля",
    span: "wide",
  },
  {
    src: steam,
    alt: "Парная бани-бочки Квадро с дровяной печью и полками",
    title: "Парная с дровяной печью",
    tag: "Парная",
  },
  {
    src: rest,
    alt: "Предбанник бани-бочки Квадро с лавкой и окном",
    title: "Предбанник — комната отдыха",
    tag: "Предбанник",
  },
  {
    src: hero,
    alt: "Баня-бочка Квадро 2×4 м с мягкой кровлей на газоне среди берёз",
    title: "«Квадро» 2 × 4 м на участке",
    tag: "Экстерьер",
  },
  {
    src: shingle,
    alt: "Мягкая кровля из гибкой черепицы бани-бочки Квадро крупным планом",
    title: "Мягкая кровля крупным планом",
    tag: "Кровля",
    focus: { x: 32, y: 42, zoom: 1.6 },
  },
  {
    src: shingleTerrace,
    alt: "Баня-бочка Квадро с мягкой кровлей из гибкой черепицы на террасе в саду",
    title: "На террасе в саду",
    tag: "Экстерьер",
  },
  {
    src: steam,
    alt: "Дровяная печь-каменка с баком для воды и деревянный ковш внутри бани-бочки Квадро",
    title: "Печь-каменка и бак для воды",
    tag: "Интерьер",
    focus: { x: 0, y: 100, zoom: 1.5 },
  },
];
