import { Container, Eyebrow, Lead, Section, Title } from "@/components/ui/Section";
import { Reveal } from "@/components/ui/Reveal";
import { GALLERY, focusStyle } from "@/data/images";
import { MODEL } from "@/data/content";
import { PlusIcon } from "@/components/ui/Icons";
import { cn } from "@/utils/cn";

type GalleryProps = { index: number; total: number; onOpen: (i: number) => void };

export function Gallery({ index, total, onOpen }: GalleryProps) {
  return (
    <Section id="gallery" index={index} total={total} className="bg-coal-950">
      <Container>
        <Reveal>
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <Eyebrow>Фотографии</Eyebrow>
              <Title>
                Посмотрите на «{MODEL}»
                <br />
                <span className="text-cream-400">снаружи и внутри</span>
              </Title>
            </div>
            <Lead className="mt-0 md:max-w-sm md:text-right">
              Нажмите на любое фото, чтобы рассмотреть детали: кровлю из гибкой черепицы, парную, предбанник и отделку.
            </Lead>
          </div>
        </Reveal>

        <div className="mt-10 grid auto-rows-[200px] grid-cols-2 gap-3 sm:auto-rows-[220px] md:grid-cols-4 md:gap-4 lg:auto-rows-[240px]">
          {GALLERY.map((item, i) => (
            <Reveal
              key={item.src + i}
              delay={i * 60}
              className={cn(
                "group relative",
                item.span === "wide" && "col-span-2",
                item.span === "tall" && "row-span-2",
              )}
            >
              <button
                onClick={() => onOpen(i)}
                className="relative block h-full w-full overflow-hidden rounded-2xl border border-cream-50/10 bg-coal-800 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember-400"
                aria-label={`Открыть фото: ${item.title}`}
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
                  style={focusStyle(item.focus)}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-coal-950/85 via-coal-950/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-100" />
                <div className="absolute left-3 top-3 rounded-full bg-coal-950/60 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-ember-300 backdrop-blur">
                  {item.tag}
                </div>
                <div className="absolute inset-x-3 bottom-3 flex items-end justify-between gap-3">
                  <span className="text-sm font-semibold leading-snug text-cream-50 drop-shadow sm:text-base">{item.title}</span>
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-cream-50/20 bg-cream-50/10 text-cream-50 opacity-0 backdrop-blur transition-all duration-300 group-hover:opacity-100">
                    <PlusIcon size={14} />
                  </span>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      </Container>
    </Section>
  );
}
