import { MANAGER_DATIVE, MAX_NAME, PHONE_TEL, PRICE_DISPLAY, SIZE, maxUrl } from "@/data/content";
import { MaxIcon, PhoneIcon } from "@/components/ui/Icons";
import { cn } from "@/utils/cn";

export function MobileBar({ visible }: { visible: boolean }) {
  return (
    <div
      className={cn(
        "fixed inset-x-0 bottom-0 z-40 p-3 transition-transform duration-500 lg:hidden",
        visible ? "translate-y-0" : "translate-y-full",
      )}
    >
      <div className="glass flex items-center gap-3 rounded-2xl p-2 pl-4 shadow-card">
        <div className="min-w-0 flex-1">
          <div className="truncate text-[10px] font-semibold uppercase tracking-[0.15em] text-cream-500">По акции · {SIZE}</div>
          <div className="whitespace-nowrap font-display text-base font-bold leading-tight text-cream-50 min-[400px]:text-lg">{PRICE_DISPLAY}</div>
        </div>
        <a
          href={maxUrl()}
          target="_blank"
          rel="noopener noreferrer"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-max-400 to-max-600 text-white"
          aria-label={`Написать в ${MAX_NAME}`}
        >
          <MaxIcon size={20} />
        </a>
        <a
          href={PHONE_TEL}
          className="inline-flex h-11 shrink-0 items-center gap-2 rounded-xl bg-gradient-to-r from-ember-400 to-ember-600 px-4 text-sm font-semibold text-coal-950 shadow-glow"
        >
          <PhoneIcon size={16} />
          Позвонить <span className="hidden min-[440px]:inline">{MANAGER_DATIVE}</span>
        </a>
      </div>
    </div>
  );
}
