import { IMAGES } from "@/data/images";
import { HERO_STATS, MANAGER_DATIVE, MODEL, PHONE_DISPLAY, PHONE_TEL, PRICE_DISPLAY, SIZE } from "@/data/content";
import { ButtonLink, Button } from "@/components/ui/Button";
import { ArrowDownIcon, PhoneIcon, SparkIcon } from "@/components/ui/Icons";
import { Reveal } from "@/components/ui/Reveal";
import { scrollToSection } from "@/hooks/useSlideKeyboard";

export function Hero() {
  return (
    <section id="hero" className="snap-slide relative flex min-h-[100svh] flex-col overflow-hidden">
      {/* Фон */}
      <div className="absolute inset-0">
        <img
          src={IMAGES.hero}
          alt="Баня-бочка Квадро 2×4 м на участке"
          className="hero-img h-full w-full object-cover object-[60%_center]"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-coal-950/95 via-coal-950/70 to-coal-950/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-coal-950 via-coal-950/30 to-coal-950/40" />
        <div className="absolute inset-0 grain" />
      </div>

      {/* Пар */}
      <div className="pointer-events-none absolute bottom-1/3 right-[18%] hidden lg:block">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="absolute h-24 w-24 rounded-full bg-cream-50/30 blur-2xl animate-steam"
            style={{ animationDelay: `${i * 1.8}s`, left: `${i * 30}px` }}
          />
        ))}
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-end px-5 pb-16 pt-32 sm:px-8 lg:justify-center lg:px-12 lg:pb-24 lg:pt-36">
        <Reveal>
          <div className="inline-flex items-center gap-2 rounded-full border border-ember-400/40 bg-ember-400/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-ember-300 backdrop-blur-md">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ember-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-ember-400" />
            </span>
            Акция · количество ограничено
          </div>
        </Reveal>

        <Reveal delay={100}>
          <h1 className="mt-6 max-w-4xl font-display text-[2.6rem] font-bold leading-[1.02] tracking-tight text-cream-50 sm:text-6xl lg:text-7xl xl:text-[5.5rem]">
            Баня-бочка
            <br />
            <span className="text-gradient-ember animate-shimmer">«{MODEL}»</span>
          </h1>
        </Reveal>

        <Reveal delay={200}>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-cream-200 sm:text-xl">
            {SIZE} · две секции · кедр · готовая русская баня, которую привозят и ставят на участок за один день.
          </p>
        </Reveal>

        <Reveal delay={300}>
          <div className="mt-8 flex flex-wrap items-end gap-x-8 gap-y-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.25em] text-cream-400">Успей купить по акции</div>
              <div className="mt-1 font-display text-5xl font-bold tracking-tight text-cream-50 sm:text-6xl">
                {PRICE_DISPLAY}
              </div>
            </div>
            <div className="mb-2 flex items-center gap-2 rounded-xl border border-cream-50/10 bg-cream-50/5 px-3 py-2 text-sm text-cream-200 backdrop-blur-md">
              <SparkIcon size={16} className="text-ember-400" />
              цена фиксируется при заказе
            </div>
          </div>
        </Reveal>

        <Reveal delay={400}>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <ButtonLink href={PHONE_TEL} size="lg">
              <PhoneIcon size={18} />
              Позвонить {MANAGER_DATIVE}
              <span className="hidden text-coal-950/70 sm:inline">· {PHONE_DISPLAY}</span>
            </ButtonLink>
            <Button variant="ghost" size="lg" onClick={() => scrollToSection("promo")}>
              Подробнее об акции
              <ArrowDownIcon size={18} className="transition-transform group-hover:translate-y-0.5" />
            </Button>
          </div>
        </Reveal>

        <Reveal delay={550}>
          <dl className="mt-12 grid max-w-3xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-cream-50/10 bg-cream-50/10 backdrop-blur-md sm:grid-cols-4 lg:mt-16">
            {HERO_STATS.map((s) => (
              <div key={s.label} className="bg-coal-950/60 px-5 py-4">
                <dt className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cream-500">{s.label}</dt>
                <dd className="mt-1 font-display text-2xl font-semibold text-cream-50">
                  {s.value} <span className="text-sm font-medium text-ember-300">{s.unit}</span>
                </dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </div>

      {/* Подсказка прокрутки */}
      <button
        onClick={() => scrollToSection("promo")}
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-cream-500 transition hover:text-ember-300 lg:flex"
        aria-label="Листать вниз"
      >
        листайте
        <span className="relative h-10 w-6 rounded-full border border-cream-50/20">
          <span className="absolute left-1/2 top-2 h-2 w-1 -translate-x-1/2 rounded-full bg-ember-400 animate-bounce" />
        </span>
      </button>
    </section>
  );
}
