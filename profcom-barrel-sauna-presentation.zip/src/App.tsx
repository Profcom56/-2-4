import { useMemo, useState } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Promo } from "@/components/Promo";
import { Gallery } from "@/components/Gallery";
import { Lightbox } from "@/components/Lightbox";
import { Specs } from "@/components/Specs";
import { FloorPlan } from "@/components/FloorPlan";
import { Advantages } from "@/components/Advantages";
import { Steps } from "@/components/Steps";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { SlideNav } from "@/components/SlideNav";
import { MobileBar } from "@/components/MobileBar";
import { SLIDES } from "@/data/content";
import { useActiveSection } from "@/hooks/useActiveSection";
import { useSlideKeyboard } from "@/hooks/useSlideKeyboard";

export default function App() {
  const slideIds = useMemo(() => SLIDES.map((s) => s.id), []);
  const activeId = useActiveSection(slideIds);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useSlideKeyboard(slideIds, activeId, lightbox === null);

  const total = SLIDES.length;
  const idx = (id: string) => SLIDES.findIndex((s) => s.id === id) + 1;

  return (
    <div className="relative min-h-screen bg-coal-950 text-cream-50">
      <Header activeId={activeId} />
      <SlideNav activeId={activeId} />

      <main>
        <Hero />
        <Promo index={idx("promo")} total={total} />
        <Gallery index={idx("gallery")} total={total} onOpen={setLightbox} />
        <Specs index={idx("specs")} total={total} />
        <FloorPlan index={idx("plan")} total={total} />
        <Advantages index={idx("advantages")} total={total} />
        <Steps index={idx("steps")} total={total} />
        <Contact index={idx("contact")} total={total} />
      </main>

      <Footer />

      <MobileBar visible={activeId !== "hero" && activeId !== "contact"} />
      <Lightbox index={lightbox} onClose={() => setLightbox(null)} onChange={setLightbox} />
    </div>
  );
}
